﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp.Core.Exams
{
    public class HackerRank
    {
        public void BotSavesPrincess()
        {
            String[] grid = {
                "---",
                "-m-",
                "p--"
            };

            int m = grid.Length;
            

        }
    }
}
